from setuptools import setup

setup(name='acunu-analytics',
      version='0.1',
      description='High level Python client for Acunu Analytics',
      url='http://www.acunu.com',
      author='Acunu',
      author_email='support@acunu.com',
      license='?',
      packages=['acunu'],
      zip_safe=False)
